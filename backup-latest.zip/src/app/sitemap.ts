import { MetadataRoute } from 'next';
import { getCategories, getActiveProductCount, getActiveProducts } from '@/lib/firebase/firestore';
import * as fs from 'fs';
import * as path from 'path';
import { getProductUrl } from '@/lib/utils';

/**
 * World-Class Sitemap Generation
 * Supports indexing of all products by splitting them into chunks.
 */

const PRODUCT_SITEMAP_SIZE = 5000; // Limit per sitemap chunk

async function getGuideRoutes(baseUrl: string): Promise<MetadataRoute.Sitemap> {
  try {
    const guidesDirectory = path.join(process.cwd(), 'src/content/guides');
    if (!fs.existsSync(guidesDirectory)) return [];

    const filenames = fs.readdirSync(guidesDirectory);
    return filenames
      .filter(file => file.endsWith('.json'))
      .map(file => {
        const slug = file.replace('.json', '');
        return {
          url: `${baseUrl}/guide/topic/${slug}`,
          lastModified: new Date(),
          changeFrequency: 'weekly',
          priority: 0.9, // High priority for high-value content
        };
      });
  } catch (error) {
    console.error('Error generating guide sitemap:', error);
    return [];
  }
}

export const revalidate = 3600; // Cache sitemap for 1 hour

export async function generateSitemaps() {
  try {
    const totalCount = await getActiveProductCount();
    const numberOfSitemaps = Math.ceil(totalCount / PRODUCT_SITEMAP_SIZE);
    const count = Math.max(1, numberOfSitemaps);
    return Array.from({ length: count }, (_, id) => ({ id }));
  } catch (error) {
    console.error('Error generating sitemaps list:', error);
    return [{ id: 0 }];
  }
}

export default async function sitemap({ id }: { id: number }): Promise<MetadataRoute.Sitemap> {
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://benched.au';
  const startOffset = id * PRODUCT_SITEMAP_SIZE;

  // 1. Static Routes (Only included on sitemap index 0)
  const staticRoutes: MetadataRoute.Sitemap = id === 0 ? [
    '',
    '/browse',
    '/shoes',
    '/cards',
    '/coins',
    '/sell',
    '/scan',
    '/drops',
    '/about',
    '/how-it-works',
    '/safety-tips',
    '/donate',
    '/vault',
    '/bidsy',
    '/consign',
    '/terms',
    '/privacy',
    '/dmca',
    '/prohibited-items'
  ].map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: 'daily',
    priority: route === '' ? 1 : 0.8,
  })) : [];

  // 2. Dynamic Categories (Only included on sitemap index 0)
  let categoryRoutes: MetadataRoute.Sitemap = [];
  if (id === 0) {
    try {
      const categories = await getCategories();
      categoryRoutes = categories
        .filter(category => category.slug)
        .map((category) => ({
          url: `${baseUrl}/${category.slug}`,
          lastModified: new Date(),
          changeFrequency: 'weekly',
          priority: 0.7,
        }));
    } catch (err) {
      console.error('Sitemap: Error fetching categories:', err);
    }
  }

  // 3. Guide Routes (Only included on sitemap index 0)
  const guideRoutes = id === 0 ? await getGuideRoutes(baseUrl) : [];

  // 4. Topic Routes (Only included on sitemap index 0)
  let topicRoutes: MetadataRoute.Sitemap = [];
  if (id === 0) {
    try {
      const { SEO_TOPICS } = await import('@/config/seo-topics');
      topicRoutes = SEO_TOPICS.map(topic => {
        let pathPrefix = 'shoes';
        if (topic.category === 'Collector Cards') pathPrefix = 'cards';
        else if (topic.category === 'Coins') pathPrefix = 'coins';

        return {
          url: `${baseUrl}/${pathPrefix}/${topic.slug}`,
          lastModified: new Date(),
          changeFrequency: 'weekly',
          priority: 0.9,
        };
      });
    } catch (err) {
      console.error('Sitemap: Error loading SEO topics:', err);
    }
  }

  // 5. Competitor Conquesting Routes (Only included on sitemap index 0)
  let conquestingRoutes: MetadataRoute.Sitemap = [];
  if (id === 0) {
    try {
      const competitors = JSON.parse(fs.readFileSync(path.join(process.cwd(), 'src/content/conquesting/competitors.json'), 'utf-8'));
      conquestingRoutes = Object.keys(competitors).map((slug) => ({
        url: `${baseUrl}/shop-at/${slug}`,
        lastModified: new Date(),
        changeFrequency: 'weekly',
        priority: 0.8,
      }));
    } catch (err) {
      console.error('Sitemap: Error loading conquesting routes:', err);
    }
  }

  // 6. Product Routes (Included on all chunks relative to id offset)
  let productRoutes: MetadataRoute.Sitemap = [];
  try {
    const activeProducts = await getActiveProducts(PRODUCT_SITEMAP_SIZE, startOffset);
    productRoutes = activeProducts.map(p => ({
      url: `${baseUrl}${getProductUrl(p)}`,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 0.6,
    }));
  } catch (err) {
    console.error(`Sitemap: Error fetching products for chunk ${id}:`, err);
  }

  return [
    ...staticRoutes,
    ...categoryRoutes,
    ...guideRoutes,
    ...topicRoutes,
    ...conquestingRoutes,
    ...productRoutes
  ];
}
