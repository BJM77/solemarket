"use client";

import Link from 'next/link';
import Image from 'next/image';
import { ArrowRight, Library, Trophy, Zap, Sparkles, Flag, PenTool as Signature, Medal } from 'lucide-react';
import { cn } from "@/lib/utils";

const CARD_CATEGORIES = [
    {
        name: 'Jordan',
        logo: '/brand-logos/svg/jordan.svg',
        href: '/cards?subCategory=Jordan',
        color: 'bg-red-50/50 dark:bg-red-950/10'
    },
    {
        name: 'Kobe',
        logo: '/brand-logos/svg/kobe.svg',
        href: '/cards?subCategory=Kobe',
        color: 'bg-purple-50/50 dark:bg-purple-950/10'
    },
    {
        name: 'Curry',
        logo: '/brand-logos/svg/curry.svg',
        href: '/cards?subCategory=Curry',
        color: 'bg-blue-50/50 dark:bg-blue-950/10'
    },
    {
        name: 'Pokemon',
        icon: Zap,
        href: '/cards?subCategory=Pok%C3%A9mon',
        color: 'bg-yellow-50 dark:bg-yellow-950/20'
    },
    {
        name: 'Top 100',
        icon: Medal,
        href: '/cards?subCategory=Top%20100',
        color: 'bg-blue-50 dark:bg-blue-950/20'
    },
    {
        name: 'Wembanyama',
        icon: Sparkles,
        href: '/cards?subCategory=Wembanyama',
        color: 'bg-indigo-50 dark:bg-indigo-950/20'
    },
    {
        name: 'Rookies',
        icon: Trophy,
        href: '/cards?subCategory=Rookies',
        color: 'bg-amber-50 dark:bg-amber-950/20'
    },
    {
        name: 'Signed',
        icon: Signature,
        href: '/cards?subCategory=Signed',
        color: 'bg-emerald-50 dark:bg-emerald-950/20'
    },
    {
        name: 'Flag',
        icon: Flag,
        href: '/cards?subCategory=Flag',
        color: 'bg-slate-50 dark:bg-slate-900/20'
    },
    {
        name: 'Basketball Cards',
        icon: Library,
        href: '/cards?subCategory=Basketball%20Cards',
        color: 'bg-orange-50 dark:bg-orange-950/20'
    },
    {
        name: 'View All',
        icon: ArrowRight,
        href: '/cards',
        color: 'bg-gray-50 dark:bg-gray-800'
    },
];

import { useSiteConfig } from '@/providers/SiteConfigProvider';

export default function CardCategoryGrid() {
    const { config } = useSiteConfig();
    const section = config.sections.find((s) => s.type === 'card_room' || s.id === 'sec-card-room');

    if (section && !section.enabled) return null;

    const title = section?.title || 'The Card Room';
    const subtitle = section?.subtitle || 'Rare wax, graded singles, and the newest sets.';
    const categories = section?.items && section.items.length > 0 ? section.items : CARD_CATEGORIES;
    const containerClasses = section?.customClasses || 'bg-background py-16 lg:py-24 border-b border-border/10 relative overflow-hidden';

    return (
        <section className={containerClasses}>
            <div className="max-w-[1440px] mx-auto px-6 md:px-10 relative z-10">
                <div className="flex flex-col md:flex-row items-end justify-between mb-8 md:mb-12 gap-3 md:gap-4">
                    <div>
                        <h2 className="text-2xl md:text-5xl font-black text-white tracking-tighter uppercase italic">{title}</h2>
                        <p className="text-xs md:text-lg text-muted-foreground mt-1 md:mt-2 font-medium">{subtitle}</p>
                    </div>
                    <Link href="/cards" className="group hidden md:flex text-sm font-black tracking-widest uppercase text-indigo-600 dark:text-indigo-400 items-center transition-all bg-indigo-500/10 px-6 py-3 rounded-full hover:bg-indigo-500/20">
                        View All Cards <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </Link>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 md:gap-6">
                    {categories.map((cat, idx) => {
                        const itemKey = ('id' in cat && cat.id) ? cat.id : `${cat.name}-${idx}`;
                        return (
                            <Link
                                key={itemKey}
                                href={cat.href}
                                className="group block"
                            >
                                <div className="relative h-full bg-card border border-white/5 rounded-2xl md:rounded-[2rem] p-4 md:p-6 flex flex-col items-center justify-center gap-3 md:gap-6 transition-all duration-500 hover:border-indigo-500/50 hover:shadow-[0_0_40px_rgba(99,102,241,0.15)] hover:-translate-y-2 overflow-hidden">
                                    <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                                    <div className={cn(
                                        "relative w-12 h-12 md:w-24 md:h-24 flex items-center justify-center p-2 rounded-2xl transition-transform duration-500 group-hover:scale-110 group-hover:rotate-3",
                                        cat.color
                                    )}>
                                        {cat.logo ? (
                                            <Image
                                                src={cat.logo}
                                                alt={`${cat.name} logo`}
                                                fill
                                                className="object-contain p-2 dark:invert filter drop-shadow-sm"
                                                sizes="(max-width: 768px) 48px, 96px"
                                            />
                                        ) : (
                                            <Sparkles className="h-6 w-6 md:h-10 md:w-10 text-muted-foreground" />
                                        )}
                                    </div>
                                    <span className="font-black text-white text-[10px] md:text-sm uppercase tracking-widest text-center relative z-10">
                                        {cat.name}
                                    </span>
                                </div>
                            </Link>
                        );
                    })}
                </div>

                <Link href="/cards" className="mt-6 md:mt-8 md:hidden group text-xs md:text-sm font-black tracking-widest uppercase text-indigo-600 dark:text-indigo-400 flex justify-center items-center transition-all bg-indigo-500/10 px-4 py-3 md:px-6 md:py-4 rounded-full hover:bg-indigo-500/20 w-full text-center">
                    View All Cards <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Link>
            </div>
        </section>
    );
}
