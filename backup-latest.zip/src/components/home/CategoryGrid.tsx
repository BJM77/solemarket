"use client";

import Link from 'next/link';
import Image from 'next/image';
import { ArrowRight, LayoutGrid, Footprints, Library } from 'lucide-react';
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { useSiteConfig } from '@/providers/SiteConfigProvider';

const CATEGORIES = [
    {
        name: 'Jordan',
        logo: '/brand-logos/svg/jordan.svg',
        href: '/shoes?subCategory=Jordan&brand=Jordan',
        color: 'bg-red-50/50 dark:bg-red-950/10'
    },
    {
        name: 'Nike',
        logo: '/brand-logos/svg/nike.svg',
        href: '/shoes?subCategory=Nike&brand=Nike',
        color: 'bg-orange-50/50 dark:bg-orange-950/10'
    },
    {
        name: 'Adidas',
        logo: '/brand-logos/svg/adidas.svg',
        href: '/shoes?subCategory=Adidas&brand=Adidas',
        color: 'bg-blue-50/50 dark:bg-blue-950/10'
    },
    {
        name: 'New Balance',
        logo: '/brand-logos/svg/new-balance.svg',
        href: '/shoes?subCategory=New%20Balance&brand=New%20Balance',
        color: 'bg-green-50/50 dark:bg-green-950/10'
    },
    {
        name: 'Under Armour',
        logo: '/brand-logos/svg/under-armour.svg',
        href: '/shoes?subCategory=Under%20Armour&brand=Under%20Armour',
        color: 'bg-slate-100/50 dark:bg-slate-800/10'
    },
    {
        name: 'Reebok',
        logo: '/brand-logos/svg/reebok.svg',
        href: '/shoes?subCategory=Reebok&brand=Reebok',
        color: 'bg-blue-50/50 dark:bg-blue-950/10'
    },
    {
        name: 'Puma',
        logo: '/brand-logos/svg/puma.svg',
        href: '/shoes?subCategory=Puma&brand=Puma',
        color: 'bg-yellow-50/50 dark:bg-yellow-950/10'
    },
    {
        name: 'Converse',
        logo: '/brand-logos/svg/converse.svg',
        href: '/shoes?subCategory=Converse&brand=Converse',
        color: 'bg-zinc-100/50 dark:bg-zinc-800/10'
    },
    {
        name: 'Kobe',
        logo: '/brand-logos/svg/kobe.svg',
        href: '/shoes?subCategory=Kobe&brand=Kobe',
        color: 'bg-purple-50/50 dark:bg-purple-950/10'
    },
    {
        name: 'LeBron',
        logo: '/brand-logos/svg/lebron.svg',
        href: '/shoes?subCategory=LeBron&brand=LeBron',
        color: 'bg-gold-50/50 dark:bg-yellow-950/10'
    },
    {
        name: 'Curry',
        logo: '/brand-logos/svg/curry.svg',
        href: '/shoes?subCategory=Curry&brand=Curry',
        color: 'bg-blue-50/50 dark:bg-blue-950/10'
    },
    {
        name: 'View All',
        icon: ArrowRight,
        href: '/browse',
        color: 'bg-gray-50 dark:bg-gray-800'
    },
];

export default function CategoryGrid() {
    const { config } = useSiteConfig();
    const section = config.sections.find((s) => s.type === 'lineup' || s.id === 'sec-lineup');
    
    if (section && !section.enabled) return null;

    const title = section?.title || 'Shop the Lineup';
    const subtitle = section?.subtitle || 'The deepest collection of basketball heritage and performance.';
    const categories = section?.items && section.items.length > 0 ? section.items : CATEGORIES;
    const containerClasses = section?.customClasses || 'bg-background py-16 lg:py-24 border-b border-border/10 relative overflow-hidden';

    return (
        <section className={containerClasses}>
            <div className="max-w-[1440px] mx-auto px-6 md:px-10 relative z-10">
                <div className="flex flex-col md:flex-row items-end justify-between mb-8 md:mb-12 gap-3 md:gap-4">
                    <div>
                        <h2 className="text-2xl md:text-5xl font-black text-slate-900 dark:text-white tracking-tighter uppercase italic">{title}</h2>
                        <p className="text-xs md:text-lg text-slate-500 dark:text-slate-400 mt-1 md:mt-2 font-medium">{subtitle}</p>
                    </div>
                    <Link href="/browse" className="group hidden md:flex text-sm font-black tracking-widest uppercase text-primary hover:text-orange-400 items-center transition-all bg-primary/10 px-6 py-3 rounded-full hover:bg-primary/20">
                        View All Market <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </Link>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 md:gap-6">
                    {categories.map((cat, idx) => {
                        const itemKey = ('id' in cat && cat.id) ? cat.id : `${cat.name}-${idx}`;
                        return (
                            <Link
                                key={itemKey}
                                href={cat.href}
                                className="group block"
                            >
                                <div className="relative h-full bg-card border border-white/5 rounded-2xl md:rounded-[2rem] p-4 md:p-6 flex flex-col items-center justify-center gap-3 md:gap-6 transition-all duration-300 hover:border-primary/50 hover:shadow-[0_0_40px_rgba(242,108,13,0.15)] hover:-translate-y-1 hover:scale-[1.02] active:scale-95 overflow-hidden">
                                    <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                                    <div className={cn(
                                        "relative w-12 h-12 md:w-24 md:h-24 flex items-center justify-center p-2 rounded-2xl transition-transform duration-500 group-hover:scale-110 group-hover:rotate-3",
                                        cat.color
                                    )}>
                                        {cat.logo ? (
                                            <Image
                                                src={cat.logo}
                                                alt={`${cat.name} logo`}
                                                fill
                                                className="object-contain p-2 dark:invert filter drop-shadow-sm"
                                                sizes="(max-width: 768px) 48px, 96px"
                                            />
                                        ) : (
                                            <Footprints className="h-6 w-6 md:h-10 md:w-10 text-slate-700 dark:text-slate-300" />
                                        )}
                                    </div>
                                    <span className="font-black text-slate-900 dark:text-white text-[10px] md:text-sm uppercase tracking-widest text-center relative z-10">
                                        {cat.name}
                                    </span>
                                </div>
                            </Link>
                        );
                    })}
                </div>

                <Link href="/browse" className="mt-6 md:mt-8 md:hidden group text-xs md:text-sm font-black tracking-widest uppercase text-primary hover:text-orange-400 flex justify-center items-center transition-all bg-primary/10 px-4 py-3 md:px-6 md:py-4 rounded-full hover:bg-primary/20 w-full text-center">
                    View All Market <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Link>
            </div>
        </section>
    );
}
