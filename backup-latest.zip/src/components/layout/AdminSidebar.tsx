
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
    Sidebar,
    SidebarContent,
    SidebarHeader,
    SidebarMenu,
    SidebarMenuItem,
    SidebarMenuButton,
    SidebarTrigger,
    SidebarFooter,
} from "@/components/ui/sidebar";
import {
    LayoutDashboard,
    Box,
    MessageSquareWarning,
    BarChart,
    ShieldCheck,
    ShieldAlert,
    Home,
    Settings,
    Zap,
    Users,
    Globe,
    Activity,
    ListChecks,
    Gavel,
    Briefcase,
    Sparkles,
    DollarSign,
    BellRing,
    Tag,
    Target,
    Palette
} from "lucide-react";
import Image from "next/image";
import { motion } from "framer-motion";
import { useUser } from "@/firebase";
import { useSidebar } from "@/components/layout/sidebar-provider";
import { cn } from "@/lib/utils";
import { useState, useEffect } from "react";

// Navigation Items Configuration
const navItems = [
    { href: "/admin", icon: LayoutDashboard, label: "Dashboard" },
    // { href: "/admin/orders", icon: ShieldCheck, label: "Escrow Ledger" },
    // { href: "/admin/payouts", icon: DollarSign, label: "Payout Ledger" },
    { href: "/admin/brand-refresh", icon: Palette, label: "Brand Refresh" },
    { href: "/admin/products/approvals", icon: Gavel, label: "Approvals" },
    { href: "/admin/products/new", icon: Sparkles, label: "New Listings" },
    { href: "/admin/sellers", icon: Briefcase, label: "Sellers" },
    { href: "/admin/products", icon: Box, label: "Products" },
    { href: "/admin/deals", icon: Sparkles, label: "Deals" },
    { href: "/admin/management", icon: ListChecks, label: "Management" },
    { href: "/admin/users", icon: Users, label: "Users" },
    { href: "/admin/members", icon: Users, label: "Members Directory" },
    { href: "/admin/disputes", icon: MessageSquareWarning, label: "Disputes" },
    { href: "/admin/analytics", icon: BarChart, label: "Analytics" },
    { href: "/admin/automation", icon: BellRing, label: "Automation" },
    { href: "/admin/wanted", icon: Tag, label: "Watch List" },
];

const integrityItems = [
    { href: "/admin/moderation", icon: ShieldCheck, label: "Moderation" },
    { href: "/admin/fraud-detection", icon: ShieldAlert, label: "Fraud Lab" },
];

const sysItems = [
    { href: "/admin/seo", icon: Globe, label: "SEO" },
    { href: "/admin/conquesting", icon: Target, label: "Conquesting" },
    { href: "/admin/categories", icon: ListChecks, label: "Categories" },
    { href: "/admin/system", icon: Activity, label: "System Health" },
    { href: "/admin/settings", icon: Settings, label: "System Settings" },
];

export default function AdminSidebar() {
    const pathname = usePathname();
    const { user } = useUser();
    const { isSidebarOpen, setIsSidebarOpen, isHovered } = useSidebar();

    // Track mobile status
    const [isMobile, setIsMobile] = useState(false);

    useEffect(() => {
        const checkMobile = () => setIsMobile(window.innerWidth < 1024);
        checkMobile();
        window.addEventListener('resize', checkMobile);
        return () => window.removeEventListener('resize', checkMobile);
    }, []);

    // Auto-close sidebar on mobile whenever the page/pathname changes
    useEffect(() => {
        if (isMobile) {
            setIsSidebarOpen(false);
        }
    }, [pathname, isMobile, setIsSidebarOpen]);

    const effectiveOpen = isSidebarOpen || (isHovered && !isMobile);

    return (
        <>
            {isMobile && isSidebarOpen && (
                <div
                    className="fixed inset-0 bg-black/50 z-[35] lg:hidden animate-in fade-in"
                    onClick={() => setIsSidebarOpen(false)}
                />
            )}
            <Sidebar>
                <SidebarHeader className="p-6">
                <div className="flex items-center justify-between w-full">
                    {effectiveOpen ? (
                        <Link href="/admin" className="block transform transition-transform hover:scale-105">
                            <Image src="/benched.png" alt="Benched Logo" width={150} height={45} className="w-auto h-10" priority />
                        </Link>
                    ) : (
                        <div className="mx-auto bg-primary/10 p-2 rounded-lg">
                            <Zap className="h-5 w-5 text-primary" />
                        </div>
                    )}
                    {effectiveOpen && <SidebarTrigger />}
                </div>
            </SidebarHeader>

            <SidebarContent className="px-4 py-2">
                <SidebarMenu>
                    <SidebarMenuItem>
                        <SidebarMenuButton asChild tooltip="Return to Marketplace">
                            <Link href="/">
                                <Home />
                                <span>Marketplace</span>
                            </Link>
                        </SidebarMenuButton>
                    </SidebarMenuItem>
                </SidebarMenu>

                <div className="my-4 px-4">
                    <div className="h-px bg-border" />
                </div>

                <SidebarMenu className="space-y-1">
                    {navItems.map((item) => {
                        const isActive = pathname === item.href || (item.href !== '/admin' && pathname.startsWith(item.href));
                        return (
                            <SidebarMenuItem key={item.href}>
                                <SidebarMenuButton
                                    asChild
                                    isActive={isActive}
                                    tooltip={item.label}
                                    className="relative group overflow-hidden"
                                    onClick={() => {
                                        if (isMobile) setIsSidebarOpen(false);
                                    }}
                                >
                                    <Link href={item.href} className="flex items-center gap-3 w-full">
                                        <item.icon className="h-5 w-5 shrink-0" />
                                        <span className={cn(
                                            "whitespace-nowrap transition-all duration-300 overflow-hidden text-sm font-medium",
                                            effectiveOpen ? "opacity-100 w-auto translate-x-0" : "opacity-0 w-0 -translate-x-2 absolute"
                                        )}>
                                            {item.label}
                                        </span>
                                    </Link>
                                </SidebarMenuButton>
                            </SidebarMenuItem>
                        );
                    })}
                </SidebarMenu>

                <div className="my-4 px-4">
                    {effectiveOpen && <div className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest px-2 mb-2">Integrity</div>}
                    <SidebarMenu className="space-y-1">
                        {integrityItems.map((item) => {
                            const isActive = pathname.startsWith(item.href);
                            return (
                                <SidebarMenuItem key={item.href}>
                                    <SidebarMenuButton
                                        asChild
                                        isActive={isActive}
                                        tooltip={item.label}
                                        onClick={() => {
                                            if (isMobile) setIsSidebarOpen(false);
                                        }}
                                    >
                                        <Link href={item.href} className="flex items-center gap-3 w-full">
                                            <item.icon className="h-5 w-5 shrink-0" />
                                            <span className={cn(
                                                "whitespace-nowrap transition-all duration-300 overflow-hidden text-sm font-medium",
                                                effectiveOpen ? "opacity-100 w-auto translate-x-0" : "opacity-0 w-0 -translate-x-2 absolute"
                                            )}>
                                                {item.label}
                                            </span>
                                        </Link>
                                    </SidebarMenuButton>
                                </SidebarMenuItem>
                            );
                        })}
                    </SidebarMenu>
                </div>

                <div className="my-4 px-4">
                    {effectiveOpen && <div className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest px-2 mb-2">Configuration</div>}
                    <SidebarMenu className="space-y-1">
                        {sysItems.map((item) => {
                            const isActive = pathname.startsWith(item.href);
                            return (
                                <SidebarMenuItem key={item.href}>
                                    <SidebarMenuButton
                                        asChild
                                        isActive={isActive}
                                        tooltip={item.label}
                                        onClick={() => {
                                            if (isMobile) setIsSidebarOpen(false);
                                        }}
                                    >
                                        <Link href={item.href} className="flex items-center gap-3 w-full">
                                            <item.icon className="h-5 w-5 shrink-0" />
                                            <span className={cn(
                                                "whitespace-nowrap transition-all duration-300 overflow-hidden text-sm font-medium",
                                                effectiveOpen ? "opacity-100 w-auto translate-x-0" : "opacity-0 w-0 -translate-x-2 absolute"
                                            )}>
                                                {item.label}
                                            </span>
                                        </Link>
                                    </SidebarMenuButton>
                                </SidebarMenuItem>
                            );
                        })}
                    </SidebarMenu>
                </div>
            </SidebarContent>

            <SidebarFooter className={cn("p-6 border-t transition-all", !effectiveOpen && "p-2 px-4")}>
                <SidebarMenu>
                    <SidebarMenuItem>
                        <SidebarMenuButton asChild tooltip="Admin Profile">
                            <Link href="/profile" className={cn("flex items-center gap-3 p-2 rounded-lg hover:bg-muted transition-all", !effectiveOpen && "justify-center gap-0 p-0")}>
                                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-primary to-accent flex items-center justify-center text-[10px] font-black text-white shrink-0">
                                    {user?.displayName?.[0] || 'A'}
                                </div>
                                {effectiveOpen && (
                                    <div className="flex flex-col">
                                        <span className="text-xs font-bold text-foreground">{user?.displayName || 'Administrator'}</span>
                                        <span className="text-[10px] text-muted-foreground font-mono tracking-tighter uppercase">Root Access</span>
                                    </div>
                                )}
                            </Link>
                        </SidebarMenuButton>
                    </SidebarMenuItem>
                </SidebarMenu>
            </SidebarFooter>
        </Sidebar>
    </>
  );
}
